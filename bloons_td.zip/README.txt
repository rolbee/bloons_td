Title: Monkey Bloons Tower Defense
Description: Build and upgrade towers to stop the bloons from escaping. Experiment with unique tower formations on randomly-generated maps over the course of 40 rounds.

To run, first install cmu_graphics from this link: https://academy.cs.cmu.edu/desktop. Place in the 'src' folder.

Play game by running 'main.py' file.

Shortcuts: Players can skip to rounds 10, 20, and 30 by opening the menu in the top-left corner of the screen. They are also able to restart the game from this menu, as well as enable "Fast Mode" and "Auto-Start", which will make the pace of the game faster and make it so rounds start automatically.